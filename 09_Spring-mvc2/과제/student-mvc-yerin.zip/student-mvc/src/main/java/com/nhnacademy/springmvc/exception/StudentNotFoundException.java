package com.nhnacademy.springmvc.exception;

public class StudentNotFoundException extends RuntimeException {
    public StudentNotFoundException(long id) {
        super("Not Found Student : " + id);
    }
}
