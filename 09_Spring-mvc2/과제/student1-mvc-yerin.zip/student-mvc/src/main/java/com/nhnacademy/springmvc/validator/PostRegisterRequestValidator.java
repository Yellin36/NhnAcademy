package com.nhnacademy.springmvc.validator;

import com.nhnacademy.springmvc.domain.StudentModifyRequest;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.regex.Pattern;

@Component
public class PostRegisterRequestValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return StudentModifyRequest.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        checkEmptyOrWhitespace(errors);

        StudentModifyRequest request = (StudentModifyRequest) target;

        checkNameFormat(errors, request);
        checkEmailFormat(errors, request);
        checkScoreFormat(errors, request);
        checkCommentFormat(errors, request);
    }

    private void checkCommentFormat(Errors errors, StudentModifyRequest request) {
        if(request.getComment().length() <= 200) {
            errors.rejectValue("comment", "", "comment max length is 200");
        }
    }

    private void checkScoreFormat(Errors errors, StudentModifyRequest request) {
        if(request.getScore() < 0 || request.getScore() > 100) {
            errors.rejectValue("score", "", "score min 0 max 100");
        }
    }

    private void checkEmailFormat(Errors errors, StudentModifyRequest request) {
        String regex = "^[_a-z0-9-]+(.[_a-z0-9-]+)*@(?:\\w+\\.)+\\w+$";

        if(!Pattern.compile(regex).matcher(request.getEmail()).matches()) {
            errors.rejectValue("email", "", "this is not an email format");
        }
    }

    private void checkNameFormat(Errors errors, StudentModifyRequest request) {
        if(request.getName().length() == 0) {
            errors.rejectValue("name", "", "name min length is 1");
        }
    }

    private void checkEmptyOrWhitespace(Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "name is null");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "", "name is null");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "score", "", "name is null");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "comment", "", "name is null");
    }
}
