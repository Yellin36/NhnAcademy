package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.Student;
import com.nhnacademy.springmvc.domain.StudentModifyRequest;
import com.nhnacademy.springmvc.exception.StudentNotFoundException;
import com.nhnacademy.springmvc.exception.ValidationFailedException;
import com.nhnacademy.springmvc.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Objects;

@Controller
@RequestMapping("/student")
public class StudentController {
    private final StudentRepository studentRepository;

    public StudentController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @ModelAttribute("student")
    public Student getStudent(@PathVariable("studentId") Long studentId) {
        Student student = studentRepository.getStudent(studentId);

        if(Objects.isNull(student)) {
            throw new StudentNotFoundException(studentId);
        }
        return student;
    }
    @GetMapping("/{studentId}")
    public String viewStudent(@ModelAttribute Student student,
                              Model model) {
        model.addAttribute("student", student);

        return "studentView";
    }
    @GetMapping(value = "/{studentId}", params = "hideScore")
    public String viewStudent(@ModelAttribute Student student,
                              @RequestParam("hideScore") String hideScore,
                              Model model) {
        if(!Objects.isNull(hideScore) && hideScore.equals("yes")) {
            model.addAttribute("student", student);

            return "studentHideView";
        }
        model.addAttribute("exception", "올바른 파라미터를 작성해주세요(yes|no)");
        return "error";
    }

    @GetMapping("/{studentId}/modify")
    public String studentModifyForm(@ModelAttribute Student student, ModelMap modelMap) {
        modelMap.put("student", student);

        return "studentModify";
    }

    @PostMapping("/{studentId}/modify")
    public String modifyStduent(@ModelAttribute Student student,
                                @Valid @ModelAttribute StudentModifyRequest studentRequest,
                                BindingResult bindingResult,
                                ModelMap modelMap) {
        if (bindingResult.hasErrors()) {
            throw new ValidationFailedException(bindingResult);
        }

        Student modifiedStudent = studentRepository.getStudent(student.getId());

        modifiedStudent.setName(studentRequest.getName());
        modifiedStudent.setEmail(studentRequest.getEmail());
        modifiedStudent.setScore(studentRequest.getScore());
        modifiedStudent.setComment(studentRequest.getComment());

        modelMap.put("student", modifiedStudent);

        return "studentView";
    }
    @ExceptionHandler(StudentNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public void handleException() { }

}
