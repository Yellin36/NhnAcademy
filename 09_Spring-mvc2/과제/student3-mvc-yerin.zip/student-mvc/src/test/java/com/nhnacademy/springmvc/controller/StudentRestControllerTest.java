package com.nhnacademy.springmvc.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnacademy.springmvc.domain.Student;
import com.nhnacademy.springmvc.domain.StudentRegistRequest;
import com.nhnacademy.springmvc.exception.StudentNotFoundException;
import com.nhnacademy.springmvc.exception.ValidationFailedException;
import com.nhnacademy.springmvc.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.util.NestedServletException;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.catchThrowable;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class StudentRestControllerTest {
    MockMvc mockMvc;
    StudentRepository studentRepository;

    @BeforeEach
    void setUp() {
        studentRepository = mock(StudentRepository.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new StudentRestController(studentRepository))
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .build();
    }

    @Test
    void getStudent_fail_invalidStudentId() throws Exception {
        long invalidStudentId = 50;

        Throwable th = catchThrowable(() ->
                mockMvc.perform(get("/students/{studentId}", invalidStudentId)
                                .accept(MediaType.APPLICATION_JSON))
        );

        assertThat(th).isInstanceOf(NestedServletException.class)
                .hasCauseInstanceOf(StudentNotFoundException.class);
    }

    @Test
    void getStudent() throws Exception {
        long studentId = 1;
        Student student = new Student(1, "김학생");

        when(studentRepository.getStudent(studentId)).thenReturn(student);

        mockMvc.perform(get("/students/{studentId}", studentId)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(studentRepository).getStudent(studentId);
    }

    @Test
    void createStudent_fail_validationFailed() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        StudentRegistRequest registerStudent = new StudentRegistRequest("student2", "sd2hn.com", 50, "good");
        String content = objectMapper.writeValueAsString(registerStudent);

        Throwable th = catchThrowable(() ->
               mockMvc.perform(post("/students")
                       .contentType(MediaType.APPLICATION_JSON)
                       .accept(MediaType.APPLICATION_JSON)
                       .content(content))
        );

        assertThat(th).isInstanceOf(NestedServletException.class)
                        .hasCauseInstanceOf(ValidationFailedException.class);

    }

    @Test
    void createStudent_success() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        StudentRegistRequest registerStudent = new StudentRegistRequest("김학생", "sd2@nhn.com", 50, "good");
        String content = objectMapper.writeValueAsString(registerStudent);


        Student student = new Student(2, "김학생", "sd2@nhn.com", 50, "good");
        when(studentRepository.register("김학생", "sd2@nhn.com", 50, "good")).thenReturn(student);

        mockMvc.perform(post("/students")
                        .content(content)
                        .contentType(MediaType.APPLICATION_JSON)

                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(2))
                .andExpect(jsonPath("$.name").value("김학생"))
                .andExpect(jsonPath("$.email").value("sd2@nhn.com"))
                .andExpect(jsonPath("$.score").value(50))
                .andExpect(jsonPath("$.comment").value("good"))
                .andDo(print());

        verify(studentRepository).register("김학생", "sd2@nhn.com", 50, "good");
    }
    @Test
    void modifyStudent_fail_validationFailed() throws Exception {
        long studentId = 2;

        ObjectMapper objectMapper = new ObjectMapper();
        StudentRegistRequest registerStudent = new StudentRegistRequest("김학생", "modifnhn.com", 800, "something 바뀜");
        String content = objectMapper.writeValueAsString(registerStudent);

        Throwable th = catchThrowable(() ->
                mockMvc.perform(put("/students/{studentId}", studentId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .content(content))
        );

        assertThat(th).isInstanceOf(NestedServletException.class)
                .hasCauseInstanceOf(ValidationFailedException.class);
    }

    @Test
    void modifyStudent_fail_invalidStudentId() throws Exception {
        long invalidStudentId = 50;

        ObjectMapper objectMapper = new ObjectMapper();
        StudentRegistRequest registerStudent = new StudentRegistRequest("김학생", "modify@nhn.com", 80, "something 바뀜");
        String content = objectMapper.writeValueAsString(registerStudent);

        Throwable th = catchThrowable(() ->
                mockMvc.perform(put("/students/{studentId}", invalidStudentId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .content(content))
        );

        assertThat(th).isInstanceOf(NestedServletException.class)
                .hasCauseInstanceOf(StudentNotFoundException.class);
    }

    @Test
    void modifyStudent_success() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        StudentRegistRequest registerStudent = new StudentRegistRequest("김학생", "modify@nhn.com", 80, "something 바뀜");
        String content = objectMapper.writeValueAsString(registerStudent);


        Student student = new Student(2, "김학생", "st2@nhn.com", 50, "good");
        when(studentRepository.getStudent(2)).thenReturn(student);

        mockMvc.perform(put("/students/{studentId}", 2)
                        .content(content)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(2))
                .andExpect(jsonPath("$.name").value("김학생"))
                .andExpect(jsonPath("$.email").value("modify@nhn.com"))
                .andExpect(jsonPath("$.score").value(80))
                .andExpect(jsonPath("$.comment").value("something 바뀜"))
                .andDo(print());

        verify(studentRepository).getStudent(2);
    }
}