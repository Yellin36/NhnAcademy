package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

class LoginControllerTest {
    MockMvc mockMvc;
    UserRepository userRepository;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new LoginController(userRepository)).build();
    }

    @Test
    void loginForm_success() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("loginForm"));

    }

    @Test
    void logout_fail_noSession() throws Exception {
        mockMvc.perform(get("/logout"))
                .andExpect(view().name("error"));
    }

    @Test
    void logout_success() throws Exception {
        MockHttpSession session = new MockHttpSession();

        session.setAttribute("sessionId", "something");

        mockMvc.perform(get("/logout")
                .session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("index"));
    }
}