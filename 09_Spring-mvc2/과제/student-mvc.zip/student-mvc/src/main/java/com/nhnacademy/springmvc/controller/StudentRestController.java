package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.Student;
import com.nhnacademy.springmvc.domain.StudentModifyRequest;
import com.nhnacademy.springmvc.domain.StudentRegistRequest;
import com.nhnacademy.springmvc.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class StudentRestController {
    private final StudentRepository studentRepository;

    public StudentRestController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @GetMapping("/students/{studentId}")
    public Student getStudent(@PathVariable("studentId") Long studentId) {
        return studentRepository.getStudent(studentId);
    }

    @PostMapping("/students")
    @ResponseStatus(HttpStatus.CREATED)
    public void createStudent(@RequestBody StudentRegistRequest student) {
        studentRepository.register(student.getName(),
                student.getEmail(),
                student.getScore(),
                student.getComment());
    }

    @PutMapping("/students/{studentId}")
    public ResponseEntity<?> modifyStudent(@PathVariable("studentId") Long studentId,
                                        @RequestBody StudentModifyRequest student) {
        Student modifiedStudent = studentRepository.getStudent(studentId);

        if(modifiedStudent == null) {
        }

        modifiedStudent.setName(student.getName());
        modifiedStudent.setEmail(student.getEmail());
        modifiedStudent.setScore(student.getScore());
        modifiedStudent.setComment(student.getComment());

        return ResponseEntity.ok(modifiedStudent);
    }



}
