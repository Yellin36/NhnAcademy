package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.UserLoginRequest;
import com.nhnacademy.springmvc.repository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;

@Controller
public class LoginController {
    private UserRepository userRepository;

    public LoginController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/login")
    public String loginForm() {
        return "loginForm";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("sessionId");

        return "index";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute UserLoginRequest user,
                        HttpSession session) {
        String id = user.getId();
        String password = user.getPassword();

        if(userRepository.matches(id, password)) {
            session.setAttribute("sessionId", id);
            return "index";
        }
        return "loginForm";
    }
}
