package com.nhnacademy.springmvc.domain;

import lombok.*;

import javax.validation.constraints.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StudentModifyRequest {
    @NotBlank
    String name;

    @Email
    String email;

    @Min(0) @Max(100)
    int score;

    @NotBlank @Size(max = 200)
    String comment;
}
