package com.nhnacademy.springmvc;

// marker interface
public interface Base {
}
