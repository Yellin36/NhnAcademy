package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.Student;
import com.nhnacademy.springmvc.domain.StudentModifyRequest;
import com.nhnacademy.springmvc.domain.StudentRegistRequest;
import com.nhnacademy.springmvc.exception.StudentNotFoundException;
import com.nhnacademy.springmvc.exception.ValidationFailedException;
import com.nhnacademy.springmvc.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class StudentRestController {
    private final StudentRepository studentRepository;

    public StudentRestController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @GetMapping("/students/{studentId}")
    @ResponseStatus(HttpStatus.OK)
    public Student  getStudent(@PathVariable("studentId") Long studentId) {
        Student student = getStudentByStudentId(studentId);

        return student;
    }
    @PostMapping("/students")
    public ResponseEntity<?> createStudent(@Valid @RequestBody StudentRegistRequest student,
                                           BindingResult bindingResult) {
        checkValidation(bindingResult);

        Student modifyStudent = studentRepository.register(
                student.getName(),
                student.getEmail(),
                student.getScore(),
                student.getComment()
        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(modifyStudent);
    }

    @PutMapping("/students/{studentId}")
    public ResponseEntity<?> modifyStudent(@PathVariable("studentId") Long studentId,
                                           @Valid @RequestBody StudentModifyRequest student,
                                           BindingResult bindingResult) {
        checkValidation(bindingResult);

        Student modifiedStudent = getStudentByStudentId(studentId);

        modifiedStudent.setName(student.getName());
        modifiedStudent.setEmail(student.getEmail());
        modifiedStudent.setScore(student.getScore());
        modifiedStudent.setComment(student.getComment());

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(modifiedStudent);
    }

    private Student getStudentByStudentId(long studentId) {
        Student student;

        if((student = studentRepository.getStudent(studentId)) == null) {
            throw new StudentNotFoundException(studentId);
        }
        return student;
    }

    private void checkValidation(BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new ValidationFailedException(bindingResult);
        }
    }

}
