package com.nhnacademy.springmvc.exception;

public class LoginFailedException extends RuntimeException {
}
