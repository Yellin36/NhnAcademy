package com.nhnacademy.springmvc.exception;

public class LogoutFailedException extends RuntimeException {
}
