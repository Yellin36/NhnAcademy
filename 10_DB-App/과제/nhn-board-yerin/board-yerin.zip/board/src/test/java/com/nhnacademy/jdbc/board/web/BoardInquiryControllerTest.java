package com.nhnacademy.jdbc.board.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class BoardInquiryControllerTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void inquiryPosts() {
    }

    @Test
    void testInquiryPosts() {
    }

    @Test
    void inquiryPostsWithTitle() {
    }

    @Test
    void inquiryPostsWithCategory() {
    }
}