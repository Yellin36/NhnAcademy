package com.nhnacademy.jdbc.board.domains.post.service.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BoardPostServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getPostsCount() {
    }

    @Test
    void getPostsCountWithLike() {
    }

    @Test
    void getPostsCountWithTitle() {
    }

    @Test
    void getDeletedPostsCount() {
    }

    @Test
    void exists() {
    }

    @Test
    void deleted() {
    }

    @Test
    void getExistPostByPostId() {
    }

    @Test
    void getSearchedPostsWithCommentCount() {
    }

    @Test
    void getPostsWithCommentCount() {
    }

    @Test
    void getDeletedPostsWithCommentCount() {
    }

    @Test
    void getLikePostsWithCommentCount() {
    }

    @Test
    void insertPost() {
    }

    @Test
    void getPostContainAll() {
    }

    @Test
    void getDeletedPostContainAll() {
    }
}