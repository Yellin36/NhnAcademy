package com.nhnacademy.jdbc.board.domains.comment.service.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BoardCommentServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getCommentsByPostId() {
    }

    @Test
    void getComment() {
    }

    @Test
    void insertComment() {
    }

    @Test
    void updateComment() {
    }

    @Test
    void deleteComment() {
    }
}