package com.nhnacademy.jdbc.board.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class BoardControllerTest {
    MockMvc mockMvc;
    @BeforeEach
    void setUp() {
    }

    @Test
    void registerPostForm() {
    }

    @Test
    void registerPost() {
    }

    @Test
    void showPostDetail() {
    }

    @Test
    void modifyPostForm() {
    }

    @Test
    void modifyPost() {
    }

    @Test
    void deletePost() {
    }
}