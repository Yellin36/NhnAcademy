package com.nhnacademy.jdbc.board.domains.like.service.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BoardLikeServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void likes() {
    }

    @Test
    void addLike() {
    }

    @Test
    void subtractLike() {
    }
}