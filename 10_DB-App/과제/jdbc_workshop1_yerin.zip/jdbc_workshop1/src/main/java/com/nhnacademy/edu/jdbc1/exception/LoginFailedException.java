package com.nhnacademy.edu.jdbc1.exception;

public class LoginFailedException extends RuntimeException {
    public LoginFailedException(String username) {
    }
}
