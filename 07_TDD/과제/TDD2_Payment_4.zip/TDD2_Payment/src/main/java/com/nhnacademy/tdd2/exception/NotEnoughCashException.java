package com.nhnacademy.tdd2.exception;

public class NotEnoughCashException extends RuntimeException {

  public NotEnoughCashException() {
    super("Not enough cash");
  }
}
