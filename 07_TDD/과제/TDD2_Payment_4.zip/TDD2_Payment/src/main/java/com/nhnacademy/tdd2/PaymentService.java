package com.nhnacademy.tdd2;

import com.nhnacademy.tdd2.exception.*;

import java.time.LocalDateTime;

public class PaymentService {

  private final CustomerRepository customerRepository;
  private final double ACCRUAL_RATE = 0.01;

  //마일리지 미사용
  public PaymentService(CustomerRepository customerRepository) {
    this.customerRepository = customerRepository;
  }

  /**
   * 결제처리
   *
   * @param amount     결재 금액
   * @param customerId 고객 아이디
   * @return 영수증
   */
  public Receipt pay(long amount, Long customerId) {
    if (amount < 0) {
      throw new InvalidElementException("Amount=" + amount);
    }

    Customer customer;
    if ((customer = customerRepository.findById(customerId)) == null) {
      throw new CustomerNotFoundException(customerId);
    }

    long cash;
    if ((cash = customer.getCash()) < amount){
      throw new NotEnoughCashException();
    }

    long exchange = purchaseAmount(customer, amount);
    long mileage = calculateMileage(customer, amount, 0);
    LocalDateTime purchaseTime = LocalDateTime.now();

    return new Receipt(customerId, purchaseTime, cash, amount, exchange, mileage);
  }
  public Receipt pay(long amount, Long customerId, Coupon coupon) {
    if (amount < 0) {
      throw new InvalidElementException("Amount=" + amount);
    }
    Customer customer;
    if ((customer = customerRepository.findById(customerId)) == null) {
      throw new CustomerNotFoundException(customerId);
    }
    long cash;
    if ((cash = customer.getCash()) < amount){
      throw new NotEnoughCashException();
    }
    amount = discountAmount(coupon, amount);

    long exchange = purchaseAmount(customer, amount);
    long mileage = calculateMileage(customer, amount, 0);
    LocalDateTime purchaseTime = LocalDateTime.now();

    return new Receipt(customerId, purchaseTime, cash, amount, exchange, mileage);
  }

  /**
   * 결제처리
   * @param amount      결재 금액
   * @param customerId  고객아이디
   * @param usingMileage 사용 마일리지
   * @return 영수증
   */
  //마일리지 사용
  public Receipt pay(long amount, Long customerId, long usingMileage) {
    if(usingMileage < 0 || amount < usingMileage ) {
      throw new InvalidElementException("Using Mileage=" + usingMileage);
    }

    if (amount < 0) {
      throw new InvalidElementException("Amount=" + amount);
    }
    Customer customer;
    if ((customer = customerRepository.findById(customerId)) == null) {
      throw new CustomerNotFoundException(customerId);
    }

    amount = useMileage(customer, amount, usingMileage);

    long cash;
    if ((cash = customer.getCash()) < amount){
      throw new NotEnoughCashException();
    }


    long exchange = purchaseAmount(customer, amount);
    long mileage = calculateMileage(customer, amount, usingMileage);
    LocalDateTime purchaseTime = LocalDateTime.now();

    return new Receipt(customerId, purchaseTime, cash, amount, exchange, mileage);
  }

  public long purchaseAmount(Customer customer, long amount) {
    if (!customer.canPayAmount(amount)){
      throw new NotEnoughCashException();
    }
    return customer.payAmount(amount);
  }
  public long calculateMileage(Customer customer, long amount, long usingMileage) {
    long mileage = (long) (amount * ACCRUAL_RATE);

    mileage -= usingMileage;
    customer.renewMileage(mileage);

    return mileage;
  }

  public long useMileage(Customer customer, long amount, long usingMileage) {
    if(customer.getMileage() < usingMileage){
      throw new NotEnoughMileageException();
    }
    return amount - usingMileage;
  }
  public long discountAmount(Coupon coupon, long amount) {
    if(!coupon.isValid(LocalDateTime.now())) {
      throw new InvalidCouponException(coupon);
    }
    return coupon.calcAmount(amount);
  }
}
