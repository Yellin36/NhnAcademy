package com.nhnacademy.tdd2;

public enum CouponType {
    FIXED, PERCENTAGE
}
