package com.nhnacademy.tdd2;

public interface Sms {
  String sendMessage(Receipt receipt);
}
