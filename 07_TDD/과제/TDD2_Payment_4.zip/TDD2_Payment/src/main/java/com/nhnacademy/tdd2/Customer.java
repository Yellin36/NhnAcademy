package com.nhnacademy.tdd2;

public class Customer {

  private long customerId;
  private String password;
  private long mileage;
  private long cash;

  public Customer(long customerId, String password) {
    this.customerId = customerId;
    this.password = password;
  }

  public long getCustomerId() {
    return this.customerId;
  }

  public long getCash() {
    return this.cash;
  }
  public void setCash(long cash) {
    this.cash = cash;
  }
  public boolean canPayAmount(long amount) {
    return this.cash >= amount;
  }
  public long payAmount(long amount) {
    this.cash -= amount;

    return this.cash;
  }

  public long getMileage() {
    return mileage;
  }
  public void renewMileage(long mileage) {
    this.mileage += mileage;
  }
}
