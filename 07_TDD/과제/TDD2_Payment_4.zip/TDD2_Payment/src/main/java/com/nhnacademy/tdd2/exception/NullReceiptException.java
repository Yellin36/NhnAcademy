package com.nhnacademy.tdd2.exception;

public class NullReceiptException extends RuntimeException {
    public NullReceiptException() {
        super("Null Receipt Exception");

    }
}
