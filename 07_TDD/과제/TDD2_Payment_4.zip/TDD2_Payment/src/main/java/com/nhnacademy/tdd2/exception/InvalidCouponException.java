package com.nhnacademy.tdd2.exception;

import com.nhnacademy.tdd2.Coupon;

public class InvalidCouponException extends RuntimeException {
    public InvalidCouponException(Coupon coupon) {
        super("Invalid coupon." + coupon);
    }
}
