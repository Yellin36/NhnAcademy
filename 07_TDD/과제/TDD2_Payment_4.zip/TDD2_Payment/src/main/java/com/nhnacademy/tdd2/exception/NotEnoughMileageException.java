package com.nhnacademy.tdd2.exception;

public class NotEnoughMileageException extends RuntimeException{

  public NotEnoughMileageException() {
    super("Not enough mileage");
  }
}
