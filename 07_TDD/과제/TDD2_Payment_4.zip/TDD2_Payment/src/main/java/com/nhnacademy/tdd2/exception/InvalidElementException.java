package com.nhnacademy.tdd2.exception;

public class InvalidElementException extends RuntimeException {
    public InvalidElementException(String message) {
        super("Invalid element. " + message);
    }
}
