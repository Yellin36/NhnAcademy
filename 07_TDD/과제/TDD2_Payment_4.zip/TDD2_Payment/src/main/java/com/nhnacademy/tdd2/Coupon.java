package com.nhnacademy.tdd2;

import java.time.LocalDateTime;

public class Coupon {
    private CouponType type;
    private long value;
    private LocalDateTime expirationPeriod;

    public Coupon(String type, long value) {
        this.type = CouponType.valueOf(type);
        this.value = value;
        this.expirationPeriod = LocalDateTime.now();
    }

    public void setExpirationPeriod(LocalDateTime expirationPeriod) {
        this.expirationPeriod = expirationPeriod;
    }

    public boolean isValid(LocalDateTime time) {
        return expirationPeriod.isAfter(time);
    }
    public long calcAmount(long amount) {
        long resultAmount = amount;

        switch (this.type) {
            case FIXED:
                resultAmount = amount - this.value;
                break;
            case PERCENTAGE:
                resultAmount = amount * (1 - this.value / 100);
                break;
        }
        return resultAmount;
    }

    @Override
    public String toString() {
        return "Coupon{" +
                "type='" + type + '\'' +
                ", value=" + value +
                ", expirationPeriod=" + expirationPeriod +
                '}';
    }
}
