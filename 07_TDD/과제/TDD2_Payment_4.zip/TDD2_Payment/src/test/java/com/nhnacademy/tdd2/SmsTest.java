package com.nhnacademy.tdd2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SmsTest {

  Sms sms;
  // SUT
  PaymentService service;
  // DOC
  CustomerRepository repository;
  Customer customer;

  @BeforeEach
  void setUp() {
    repository = mock(CustomerRepository.class);
    service = new PaymentService(repository);
  }

  @Test
  void sendMessageTest() {
    Sms fakeSms = new FakeSms();

    long amount = 1_000L;
    Long customerId = 3423432L;
    String password = "validPw";

    customer = new Customer(customerId, password);
    customer.setCash(1_500L);

    when(repository.findById(customerId)).thenReturn(customer);
    Receipt receipt = service.pay(amount, customerId);

    assertThat(fakeSms.sendMessage(receipt)).contains("Payment Finished");
  }
}


