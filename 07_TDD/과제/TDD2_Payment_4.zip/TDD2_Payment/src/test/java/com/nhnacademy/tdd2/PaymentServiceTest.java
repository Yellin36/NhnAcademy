package com.nhnacademy.tdd2;

import com.nhnacademy.tdd2.exception.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PaymentServiceTest {

  // SUT
  PaymentService service;
  // DOC
  CustomerRepository repository;

  Customer customer;

  @BeforeEach
  void setUp() {
    Long customerId = 3423432L;
    String password = "validPw";

    repository = mock(CustomerRepository.class);

    service = new PaymentService(repository);

    customer = new Customer(customerId, password);
  }

  //계정 존재 여부 체크
  @Test
  void pay_notFoundCustomer_thenThrowCustomerNotFoundException() {
    long amount = 10_000L;
    Long customerId = customer.getCustomerId();

    when(repository.findById(customerId)).thenReturn(null);

    assertThatThrownBy(() -> service.pay(amount, customerId))
        .isInstanceOf(CustomerNotFoundException.class)
        .hasMessageContaining("Not found customer", customerId.toString());
  }

  //결제 금액 음수 테스트
  @Test
  void pay_invalidAmount_thenThrowInvalidElementException() {
    long amount = -1L;
    Long customerId = customer.getCustomerId();

    assertThatThrownBy(() -> service.pay(amount, customerId))
            .isInstanceOf(InvalidElementException.class)
            .hasMessageContaining("Invalid element.", amount);
  }
  //잔액 부족
  @Test
  void pay_notEnoughCash_thenThrowNoEnoughCashException() {
    long amount = 1000L;
    Long customerId = customer.getCustomerId();

    customer.setCash(999L);
    when(repository.findById(customerId)).thenReturn(customer);

    assertThatThrownBy(() -> service.pay(amount, customerId))
            .isInstanceOf(NotEnoughCashException.class)
            .hasMessageContaining("Not enough cash");
  }
  //적립금 음수/물건가격오버 체크
  @ParameterizedTest
  @ValueSource(longs = {-1L, 100000L})
  void pay_InvalidMileage_thenThrowInvalidElementException(long invalidMileage) {
    long amount = 1000L;
    Long customerId = customer.getCustomerId();

    when(repository.findById(customerId)).thenReturn(customer);

    assertThatThrownBy(() -> service.pay(amount, customerId, invalidMileage))
            .isInstanceOf(InvalidElementException.class)
            .hasMessageContaining("Invalid element.", invalidMileage);
  }
  //적립금보다 물건가격이 더 많아 사용 불가능한 경우
  @Test
  void pay_notEnoughMileage_thenThrowNotEnoughMileageException() {
    long amount = 1000L;
    Long customerId = customer.getCustomerId();
    long overMileage = 700L;
    long mileage = 500L;

    customer.renewMileage(mileage);
    when(repository.findById(customerId)).thenReturn(customer);

    assertThatThrownBy(() -> service.pay(amount, customerId, overMileage))
            .isInstanceOf(NotEnoughMileageException.class)
            .hasMessageContaining("Not enough mileage");
  }
  //==============================Exception check complete!!

  //결재 성공
  @Test
  void pay_success() {
    long amount = 1000L;
    Long customerId = customer.getCustomerId();

    customer.setCash(2000L);
    when(repository.findById(customerId)).thenReturn(customer);

    Receipt receipt = service.pay(amount, customerId);

    assertThat(receipt).isNotNull();
    assertThat(receipt.getMileage()).isEqualTo((long) (amount * 0.01));
  }
  //결재 성공-마일리지 사용
  @Test
  void pay_success_withMileage() {
    Long customerId = customer.getCustomerId();
    long amount = 1000L;
    long usingMileage = 500L;

    customer.setCash(2000L);
    customer.renewMileage(1000L);
    when(repository.findById(customerId)).thenReturn(customer);

    assertThat(service.pay(amount, customerId, usingMileage)).isInstanceOf(Receipt.class);
  }
  @Test
  void pay_success_withCoupon() {
    Long customerId = customer.getCustomerId();
    long amount = 1000L;
    long usingMileage = 500L;

    Coupon coupon = new Coupon("PERCENTAGE", 10L);
    coupon.setExpirationPeriod(LocalDateTime.of(2023, 10,12, 15, 24));

    customer.setCash(2000L);
    when(repository.findById(customerId)).thenReturn(customer);

    assertThat(service.pay(amount, customerId, coupon)).isInstanceOf(Receipt.class);

  }
  //=============================successful case complete
  //고객의 구매가능 체크
  @Test
  void checkPurchaseAmount() {
    long amount = 1000L;
    long cash = 2000L;

    customer.setCash(cash);

    assertThat(service.purchaseAmount(customer, amount)).isEqualTo(cash - amount);

  }

  //마일리지 사용가능 체크
  @Test
  void checkUseMileage() {
    long amount = 1000L;
    long mileage = 500L;
    long usingMileage = 200L;

    customer.renewMileage(mileage);

    assertThat(service.useMileage(customer, amount, usingMileage)).isEqualTo(amount - usingMileage);
  }


  @Test
  void checkCalculateMileage() {
    long amount = 1000L;
    long mileage = 500L;
    long usingMileage = 200L;

    customer.renewMileage(mileage);

    assertThat(service.calculateMileage(customer, amount, usingMileage)).isEqualTo((long) (amount * 0.01 - usingMileage));
  }

  @Test
  void pay_invalidCoupon_thenThrowInvalidCouponException() {
    long amount = 1000L;
    Long customerId = customer.getCustomerId();

    Coupon coupon = new Coupon("FIXED", 100L);
    coupon.setExpirationPeriod(LocalDateTime.of(2020, 10, 2, 12, 34));

    customer.setCash(2000L);
    when(repository.findById(customerId)).thenReturn(customer);

    assertThatThrownBy(() -> service.pay(amount, customerId, coupon))
            .isInstanceOf(InvalidCouponException.class)
            .hasMessageContaining("Invalid coupon.", coupon);
  }

  @Test
  void checkDiscountAmount() {
    long amount = 1000L;
    Long customerId = customer.getCustomerId();
    long expectedAmount = 900L;

    Coupon coupon = new Coupon("FIXED", 100L);
    coupon.setExpirationPeriod(LocalDateTime.of(2023, 10, 2, 12, 34));

    customer.setCash(2000L);
    when(repository.findById(customerId)).thenReturn(customer);

    assertThat(service.discountAmount(coupon, amount)).isEqualTo(expectedAmount);
  }
}
