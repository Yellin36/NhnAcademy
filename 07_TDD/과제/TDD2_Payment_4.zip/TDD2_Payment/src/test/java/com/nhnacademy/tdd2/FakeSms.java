package com.nhnacademy.tdd2;

import com.nhnacademy.tdd2.exception.NullReceiptException;

import java.util.Objects;

public class FakeSms implements Sms {
    @Override
    public String sendMessage(Receipt receipt) {
        if (Objects.isNull(receipt)) {
            throw new NullReceiptException();
        }
        return "Payment Finished";
    }
}
