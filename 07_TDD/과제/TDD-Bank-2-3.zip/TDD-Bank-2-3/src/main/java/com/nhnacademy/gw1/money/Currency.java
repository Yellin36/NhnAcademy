package com.nhnacademy.gw1.money;

public enum Currency {
    WON, DOLLAR, EURO;
}
