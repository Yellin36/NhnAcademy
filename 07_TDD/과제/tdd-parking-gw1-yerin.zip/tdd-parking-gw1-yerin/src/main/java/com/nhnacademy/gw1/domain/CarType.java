package com.nhnacademy.gw1.domain;

public enum CarType {
    LIGHT,
    MEDIUM,
    LARGE
}
