package com.nhnacademy.gw1.parking;

public class InvalidInputException extends RuntimeException {
    public InvalidInputException() {
        super("Invalid Input");
    }
}
