package com.nhnacademy.simple_httpd.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread {
    private final int portNum;
    private ServerSocket serverSocket;
    private ServerReceiver serverReceiver;
    private ServerSender serverSender;
    public Server(int portNum) {
        this.portNum = portNum;
        try {
            this.serverSocket = new ServerSocket(portNum);
        } catch (IOException e) {
            System.out.println("failed to make server");
        }
    }


    @Override
    public void run() {
        Socket socket;
        try {
            socket = serverSocket.accept();
            System.out.println("success to connect(" + socket.getLocalSocketAddress() + ")");

            serverReceiver = new ServerReceiver(socket, portNum);

            serverReceiver.start();

            while(socket != null) {}

        } catch (IOException e) {
            System.out.println("failed to connect");
        }
    }

}
