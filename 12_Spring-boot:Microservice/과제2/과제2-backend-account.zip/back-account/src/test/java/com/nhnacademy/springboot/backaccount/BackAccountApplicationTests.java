package com.nhnacademy.springboot.backaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackAccountApplicationTests {

    @Test
    void contextLoads() {
    }

}
