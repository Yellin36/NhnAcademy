package com.nhnacademy.springboot.backaccount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackAccountApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackAccountApplication.class, args);
    }

}
