package com.nhnacademy.springboot.account.openaccount.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnacademy.springboot.account.openaccount.config.AccountProperties;
import com.nhnacademy.springboot.account.openaccount.domain.Account;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OpenAPIAccountService implements AccountService {
    private final AccountProperties accountProperties;

    @Override
    public List<Account> getAccounts() {
        RestTemplate rt = new RestTemplate();

        ResponseEntity<List> githubResponse = rt.exchange(
                accountProperties.getUrl(),
                HttpMethod.GET,
                getHttpEntity(),
                List.class
        );
        ObjectMapper mapper = new ObjectMapper();

        return (List<Account>) githubResponse.getBody().stream()
                .map(o -> mapper.convertValue(o, Account.class))
                .collect(Collectors.toList());
    }

    @Override
    public Account getAccount(Long id) {
        RestTemplate rt = new RestTemplate();

        ResponseEntity<Account> response = rt.exchange(
                accountProperties.getUrl() + "/" + id,
                HttpMethod.GET,
                getHttpEntity(),
                Account.class
        );
        return response.getBody();
    }

    @Override
    public Account createAccount(Account account) {
        RestTemplate rt = new RestTemplate();

        ResponseEntity<Account> response = rt.exchange(
                accountProperties.getUrl(),
                HttpMethod.POST,
                getHttpEntityWithAccount(account),
                Account.class
        );
        return response.getBody();
    }

    @Override
    public String deleteAccount(Long id) {
        RestTemplate rt = new RestTemplate();

        return rt.exchange(
                accountProperties.getUrl() + "/" + id,
                HttpMethod.DELETE,
                getHttpEntity(),
                String.class
        ).getBody();
    }

    private HttpEntity getHttpEntityWithAccount(Account account) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-type", "application/json");

        Map<String, Object> params = new HashMap<>();
        params.put("id", account.getId());
        params.put("balance", account.getBalance());
        params.put("number", account.getNumber());

        return new HttpEntity<>(params, headers);
    }

    private HttpEntity getHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-type", "application/json");

        return new HttpEntity<>(headers);
    }
}
