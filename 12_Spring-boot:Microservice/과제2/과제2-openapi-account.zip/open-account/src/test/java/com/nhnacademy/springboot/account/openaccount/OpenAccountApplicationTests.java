package com.nhnacademy.springboot.account.openaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenAccountApplicationTests {

    @Test
    void contextLoads() {
    }

}
