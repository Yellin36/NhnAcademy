package com.nhnacademy.springboot.department.service;

public interface DBSettingService {
    void dbSetting(String fileName);
}
