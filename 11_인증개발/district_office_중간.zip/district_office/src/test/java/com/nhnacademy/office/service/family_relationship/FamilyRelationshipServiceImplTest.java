package com.nhnacademy.office.service.family_relationship;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FamilyRelationshipServiceImplTest {

    @Test
    void registerFamilyRelationship() {
    }

    @Test
    void updateFamilyRelationship() {
    }

    @Test
    void deleteFamilyRelationship() {
    }
}