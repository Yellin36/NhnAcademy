package com.nhnacademy.office.service;

public interface ServiceBase {
}
