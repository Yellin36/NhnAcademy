package com.nhnacademy.office.service.issue_history;

import com.nhnacademy.office.domain.CertificateCode;
import com.nhnacademy.office.entity.IssueHistory;
import com.nhnacademy.office.entity.Resident;
import com.nhnacademy.office.exception.NotFoundException;
import com.nhnacademy.office.repository.issue_history.IssueHistoryRepository;
import com.nhnacademy.office.repository.resident.ResidentRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@Transactional
public class IssueHistoryServiceImpl implements IssueHistoryService {
    private final IssueHistoryRepository issueHistoryRepository;
    private final ResidentRepository residentRepository;

    public IssueHistoryServiceImpl(IssueHistoryRepository issueHistoryRepository, ResidentRepository residentRepository) {
        this.issueHistoryRepository = issueHistoryRepository;
        this.residentRepository = residentRepository;
    }

    @Override
    public void addCertificateInquiryHistory(Long residentSerialNumber, CertificateCode code) {
        IssueHistory issueHistory = new IssueHistory();

        IssueHistory.Pk pk = new IssueHistory.Pk(residentSerialNumber, LocalDateTime.now());
        Resident resident = residentRepository.findByResidentSerialNumber(residentSerialNumber)
                .orElseThrow(() -> new NotFoundException(Resident.class, residentSerialNumber));

        issueHistory.setPk(pk);
        issueHistory.setCertificateTypeCode(code.getValue());
        issueHistory.setResident(resident);

        issueHistoryRepository.save(issueHistory);
    }

    @Override
    public Page<IssueHistory> getIssueHistories(Pageable pageable, Long residentSerialNumber) {
        return issueHistoryRepository.getAllByPk_ResidentSerialNumber(pageable, residentSerialNumber);
    }
}
