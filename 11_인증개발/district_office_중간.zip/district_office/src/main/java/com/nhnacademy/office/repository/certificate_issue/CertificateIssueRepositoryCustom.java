package com.nhnacademy.office.repository.certificate_issue;

import com.nhnacademy.office.domain.certificate_issue.CertificateFamilyRelationshipDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateResidentRegistrationDto;
import com.nhnacademy.office.entity.Resident;

import java.util.List;
import java.util.Map;

public interface CertificateIssueRepositoryCustom {
    List<CertificateFamilyRelationshipDto> getFamilyRelationCertificateByResident(Resident resident);

    List<CertificateResidentRegistrationDto> getResidentRegistrationCertificateByResident(Resident resident);
}
