package com.nhnacademy.office.repository.birth_death_report_resident;

import com.nhnacademy.office.domain.certificate_issue.CertificateBirthReportDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateDeathReportDto;
import com.nhnacademy.office.entity.Resident;

import java.util.List;
import java.util.Map;

public interface BirthDeathResidentRepositoryCustom {

    List<CertificateBirthReportDto> getBirthReportCertificateByResident(Resident residentO);

    List<CertificateDeathReportDto> getDeathReportCertificateByResident(Resident resident);
}
