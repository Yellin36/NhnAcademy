package com.nhnacademy.office.domain.issue_history;

import java.time.LocalDateTime;

public class IssueHistoryDto {
    String certificateTypeCode;
    LocalDateTime historyDate;
}
