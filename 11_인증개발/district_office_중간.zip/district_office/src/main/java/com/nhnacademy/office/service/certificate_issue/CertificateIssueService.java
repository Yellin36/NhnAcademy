package com.nhnacademy.office.service.certificate_issue;

import com.nhnacademy.office.domain.certificate_issue.CertificateBirthReportDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateDeathReportDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateFamilyRelationshipDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateResidentRegistrationDto;

public interface CertificateIssueService {
    CertificateFamilyRelationshipDto getFamilyRelationshipCertificate(Long serialNumber);

    CertificateResidentRegistrationDto getResidentRegistrationCertificate(Long serialNumber);

    CertificateBirthReportDto getBirthReportCertificate(Long serialNumber);

    CertificateDeathReportDto getDeathReportCertificate(Long serialNumber);
}
