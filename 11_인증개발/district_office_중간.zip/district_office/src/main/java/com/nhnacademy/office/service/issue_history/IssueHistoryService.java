package com.nhnacademy.office.service.issue_history;

import com.nhnacademy.office.domain.CertificateCode;
import com.nhnacademy.office.entity.IssueHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface IssueHistoryService {

    void addCertificateInquiryHistory(Long residentSerialNumber, CertificateCode code);
    Page<IssueHistory> getIssueHistories(Pageable pageable, Long residentSerialNumber);
}
