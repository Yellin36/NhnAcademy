package com.nhnacademy.office.repository.issue_history;

import com.nhnacademy.office.entity.IssueHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface IssueHistoryRepository extends JpaRepository<IssueHistory, IssueHistory.Pk> {
    Page<IssueHistory> getAllByPk_ResidentSerialNumber(Pageable pageable, Long residentSerialNumber);

    @Transactional
    @Modifying
    @Query("delete from IssueHistory " +
            "where pk.residentSerialNumber = :serialNumber")
    void deleteByResidentSerialNumber(@Param("serialNumber") Long residentSerialNumber);
}
