package com.nhnacademy.office.config;

import com.nhnacademy.office.auth.LoginSuccessHandler;
import com.nhnacademy.office.service.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@EnableWebSecurity(debug = true)
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Configuration
//@ComponentScan(basePackageClasses = ServiceBase.class)
public class SecurityConfig {
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests()
                    .antMatchers("/resident/**").hasAuthority("ROLE_USER")
                    .antMatchers("/certificate/**").hasAuthority("ROLE_USER")
                    .antMatchers("/redirect-index").authenticated()
                .anyRequest().permitAll()
                .and()
                .formLogin()
                .loginPage("/basic/login")
                .loginProcessingUrl("/login")
                    .usernameParameter("id")
                    .passwordParameter("password")
                    .successHandler(loginSuccessHandler(null))
//                .and()
//                .oauth2Login()
//                .loginProcessingUrl("/auth/login")
//                .successHandler(loginSuccessHandler(null))
                    .and()
                .csrf()
                    .and()
                .exceptionHandling()
                    .accessDeniedPage("/error")
                 .and()
                .build();

    }

    @Bean
    public AuthenticationProvider authenticationProvider(CustomUserDetailsService customUserDetailService) {
        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(customUserDetailService);
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationSuccessHandler loginSuccessHandler(RedisTemplate<String, String> redisTemplate) {
        return new LoginSuccessHandler(redisTemplate);
    }



    @Bean
    public OAuth2AuthorizedClientService authorizedClientService() {
        return new InMemoryOAuth2AuthorizedClientService(clientRegistrationRepository());
    }

    @Bean
    public ClientRegistrationRepository clientRegistrationRepository() {
        return new InMemoryClientRegistrationRepository(getGithub());
    }


    private ClientRegistration getGithub() {
        return CommonOAuth2Provider.GITHUB.getBuilder("github")
                .userNameAttributeName("name")
                .clientId("8b74a626071cb04005f2")
                .clientSecret("9cc7446f5a6bd34216e1cc5dddb8b63904baafbe")
                .build();
    }
}
