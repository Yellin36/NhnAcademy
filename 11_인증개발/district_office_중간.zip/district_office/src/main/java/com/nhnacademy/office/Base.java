package com.nhnacademy.office;

public interface Base {
}
