package com.nhnacademy.office.domain.household_movement_address;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class HouseholdMovementAddressModifyRequest {
    String lastAddressYn;
}
