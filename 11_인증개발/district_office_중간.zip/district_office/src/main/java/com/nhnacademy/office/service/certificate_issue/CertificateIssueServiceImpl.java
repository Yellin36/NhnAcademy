package com.nhnacademy.office.service.certificate_issue;

import com.nhnacademy.office.domain.QualificationCode;
import com.nhnacademy.office.domain.certificate_issue.CertificateBirthReportDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateDeathReportDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateFamilyRelationshipDto;
import com.nhnacademy.office.domain.certificate_issue.CertificateResidentRegistrationDto;
import com.nhnacademy.office.domain.household_composition_resident.HouseholdCompositionResidentDto;
import com.nhnacademy.office.domain.household_movement_address.HouseholdMovementAddressDto;
import com.nhnacademy.office.domain.resident.ResidentFamilyDto;
import com.nhnacademy.office.domain.resident.ResidentRelationDto;
import com.nhnacademy.office.entity.CertificateIssue;
import com.nhnacademy.office.entity.Resident;
import com.nhnacademy.office.exception.NotFoundException;
import com.nhnacademy.office.exception.NotIssuedCertificateException;
import com.nhnacademy.office.repository.birth_death_report_resident.BirthDeathResidentRepository;
import com.nhnacademy.office.repository.certificate_issue.CertificateIssueRepository;
import com.nhnacademy.office.repository.household_composition_resident.HouseholdCompositionResidentRepository;
import com.nhnacademy.office.repository.household_movement_address.HouseholdMovementAddressRepository;
import com.nhnacademy.office.repository.resident.ResidentRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@Transactional
public class CertificateIssueServiceImpl implements CertificateIssueService {
    private final CertificateIssueRepository certificateIssueRepository;
    private final ResidentRepository residentRepository;
    private final HouseholdMovementAddressRepository householdMovementAddressRepository;
    private final HouseholdCompositionResidentRepository householdCompositionResidentRepository;

    private final BirthDeathResidentRepository birthDeathResidentRepository;

    public CertificateIssueServiceImpl(CertificateIssueRepository certificateIssueRepository,
                                       ResidentRepository residentRepository,
                                       HouseholdMovementAddressRepository householdMovementAddressRepository,
                                       HouseholdCompositionResidentRepository householdCompositionResidentRepository,
                                       BirthDeathResidentRepository birthDeathResidentRepository) {
        this.certificateIssueRepository = certificateIssueRepository;
        this.residentRepository = residentRepository;
        this.householdMovementAddressRepository = householdMovementAddressRepository;
        this.householdCompositionResidentRepository = householdCompositionResidentRepository;
        this.birthDeathResidentRepository = birthDeathResidentRepository;
    }

    @Override
    public CertificateFamilyRelationshipDto getFamilyRelationshipCertificate(Long serialNumber) {
        Resident resident = residentRepository.findByResidentSerialNumber(serialNumber)
                .orElseThrow(() -> new NotFoundException(Resident.class, serialNumber));

        CertificateFamilyRelationshipDto certificateFamilyRelationship = getCertificateFamilyRelationship(resident);

        List<ResidentRelationDto> family =
                residentRepository.getResidentRelationByResidentSerialNumber(serialNumber);

        certificateFamilyRelationship.setFamily(family);
        return certificateFamilyRelationship;
    }

    private CertificateFamilyRelationshipDto getCertificateFamilyRelationship(Resident resident) {
        if (!certificateIssueRepository.existsByResidentAndCertificateTypeCode(resident, "가족관계증명서")) {
            registerFamilyRelationshipCertificate(resident);
        }
        CertificateFamilyRelationshipDto certificateFamilyRelationship =
                certificateIssueRepository.getFamilyRelationCertificateByResident(resident).get(0);
        return certificateFamilyRelationship;
    }

    @Override
    public CertificateResidentRegistrationDto getResidentRegistrationCertificate(Long serialNumber) {
        Resident resident = residentRepository.findByResidentSerialNumber(serialNumber)
                .orElseThrow(() -> new NotFoundException(Resident.class, serialNumber));

        if (!certificateIssueRepository.existsByResidentAndCertificateTypeCode(resident, "주민등록등본")) {
            throw new NotIssuedCertificateException("주민등록등본");
        }
        CertificateResidentRegistrationDto certificateResidentRegistration =
                certificateIssueRepository.getResidentRegistrationCertificateByResident(resident).get(0);

        Long householdSerialNumber = certificateResidentRegistration.getHouseholdSerialNumber();
        List<HouseholdMovementAddressDto> address = householdMovementAddressRepository.getByHouseholdSerialNumber(householdSerialNumber);
        List<HouseholdCompositionResidentDto> composition = householdCompositionResidentRepository.getByHouseholdSerialNumber(householdSerialNumber);

        certificateResidentRegistration.setAddress(address);
        certificateResidentRegistration.setComposition(composition);

        return certificateResidentRegistration;
    }

    @Override
    public CertificateBirthReportDto getBirthReportCertificate(Long serialNumber) {
        Resident resident = residentRepository.findByResidentSerialNumber(serialNumber)
                .orElseThrow(() -> new NotFoundException(Resident.class, serialNumber));

        CertificateBirthReportDto birthReportCertificate =
                birthDeathResidentRepository.getBirthReportCertificateByResident(resident).get(0);

        ResidentFamilyDto father = getFamily(resident, QualificationCode.FATHER);
        ResidentFamilyDto mother = getFamily(resident, QualificationCode.MOTHER);

        birthReportCertificate.setFather(father);
        birthReportCertificate.setMother(mother);

        return birthReportCertificate;
    }

    @Override
    public CertificateDeathReportDto getDeathReportCertificate(Long serialNumber) {
        Resident resident = residentRepository.findByResidentSerialNumber(serialNumber)
                .orElseThrow(() -> new NotFoundException(Resident.class, serialNumber));

        CertificateDeathReportDto deathReportCertificate =
                birthDeathResidentRepository.getDeathReportCertificateByResident(resident).get(0);

        return deathReportCertificate;
    }

    private ResidentFamilyDto getFamily(Resident resident, QualificationCode code) {
        List<ResidentFamilyDto> family = residentRepository.getByResident(resident, code);
        return (Objects.equals(family.size(), 0)) ? null : family.get(0);
    }

    public void registerFamilyRelationshipCertificate(Resident resident) {
        CertificateIssue certificateIssue = new CertificateIssue();

        Long certificateConfirmationNumber = getValidCertificateConfirmationNumber();

        certificateIssue.setCertificateConfirmationNumber(certificateConfirmationNumber);
        certificateIssue.setResident(resident);
        certificateIssue.setCertificateTypeCode("가족관계증명서");
        certificateIssue.setCertificateIssueDate(LocalDate.now());

        certificateIssueRepository.save(certificateIssue);
    }

    private Long getValidCertificateConfirmationNumber() {
        Long certificateConfirmationNumber;

        do {
            certificateConfirmationNumber = Long.parseLong(RandomStringUtils.random(16, "123456789"));
        } while (certificateIssueRepository.existsByCertificateConfirmationNumber(certificateConfirmationNumber));

        return certificateConfirmationNumber;
    }
}
