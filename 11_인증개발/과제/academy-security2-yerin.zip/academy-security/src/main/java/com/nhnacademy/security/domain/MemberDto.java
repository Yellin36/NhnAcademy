package com.nhnacademy.security.domain;

import lombok.Data;

@Data
public class MemberDto {
    private String id;
    private String pwd;

}
