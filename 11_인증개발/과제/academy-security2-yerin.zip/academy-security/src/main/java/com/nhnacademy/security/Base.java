package com.nhnacademy.security;

// marker interface
public interface Base {
}
