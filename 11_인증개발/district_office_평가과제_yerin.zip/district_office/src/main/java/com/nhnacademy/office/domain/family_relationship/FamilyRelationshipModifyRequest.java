package com.nhnacademy.office.domain.family_relationship;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class FamilyRelationshipModifyRequest {
    private String relationShip;
}
