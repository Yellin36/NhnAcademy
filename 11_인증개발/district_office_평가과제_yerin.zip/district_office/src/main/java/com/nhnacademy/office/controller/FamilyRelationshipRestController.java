package com.nhnacademy.office.controller;

import com.nhnacademy.office.domain.family_relationship.FamilyRelationshipModifyRequest;
import com.nhnacademy.office.domain.family_relationship.FamilyRelationshipRegisterRequest;
import com.nhnacademy.office.entity.FamilyRelationship;
import com.nhnacademy.office.service.family_relationship.FamilyRelationshipService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/residents/{serialNumber}/relationship")
public class FamilyRelationshipRestController {
    private final FamilyRelationshipService familyRelationshipService;

    public FamilyRelationshipRestController(FamilyRelationshipService familyRelationshipService) {
        this.familyRelationshipService = familyRelationshipService;
    }

    @PostMapping
    public ResponseEntity<FamilyRelationship> registerFamilyRelationship(@PathVariable("serialNumber") Long serialNumber,
                                                         @RequestBody FamilyRelationshipRegisterRequest request) {
        FamilyRelationship familyRelationship =  familyRelationshipService.registerFamilyRelationship(serialNumber, request);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(familyRelationship);
    }

    @ResponseStatus(HttpStatus.CREATED)
    @PutMapping("/{familySerialNumber}")
    public ResponseEntity updateFamilyRelationship(@PathVariable("serialNumber") Long residentSerialNumber,
                                          @PathVariable("familySerialNumber") Long familySerialNumber,
                                          @RequestBody FamilyRelationshipModifyRequest request) {
        familyRelationshipService.updateFamilyRelationship(residentSerialNumber, familySerialNumber, request);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @ResponseStatus(HttpStatus.OK)
    @DeleteMapping("/{familySerialNumber}")
    public ResponseEntity deleteFamilyRelationship(@PathVariable("serialNumber") Long residentSerialNumber,
                                         @PathVariable("familySerialNumber") Long familySerialNumber) {
        familyRelationshipService.deleteFamilyRelationship(residentSerialNumber, familySerialNumber);

        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
