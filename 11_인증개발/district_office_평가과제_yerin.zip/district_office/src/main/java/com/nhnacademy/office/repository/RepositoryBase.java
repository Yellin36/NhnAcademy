package com.nhnacademy.office.repository;

public interface RepositoryBase {
}
