package com.nhnacademy.office.controller;

public interface ControllerBase {
}
